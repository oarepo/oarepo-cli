# uritemplate.py

This is a replacement for invenio's dependency to uritemplate.py
from invenio-oauthclient.

When this package is fixed, this one will be removed

